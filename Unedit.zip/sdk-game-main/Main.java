
import io.socket.emitter.Emitter;
import jsclub.codefest2024.sdk.*;
import jsclub.codefest2024.sdk.algorithm.PathUtils;
import jsclub.codefest2024.sdk.base.Node;
import jsclub.codefest2024.sdk.factory.WeaponFactory;
import jsclub.codefest2024.sdk.model.*;
import jsclub.codefest2024.sdk.model.equipments.*;
import jsclub.codefest2024.sdk.model.obstacles.Obstacle;
import jsclub.codefest2024.sdk.model.players.Player;
import jsclub.codefest2024.sdk.model.weapon.Weapon;

import java.awt.*;
import java.util.*;
import java.io.*;
import java.util.List;

public class Main {
    private static final String SERVER_URL = "http://192.168.50.20";
    private static final String GAME_ID = "104475";
    private static final String PLAYER_NAME = "BurnedBing";
    private static final String PLAYER_KEY = "9576b1db-2ac8-4534-80da-21feec8bba8d";
    private static final List<Node> DIRECTIONS = Arrays.asList(new Node(0, 1), new Node(0, -1), new Node(1, 0),
            new Node(-1, 0));
    private static final List<Node> DIRECTIONS_REVERSE = Arrays.asList(new Node(0, -1), new Node(0, 1), new Node(-1, 0),
            new Node(1, 0));
    private static final List<String> DIRECTIONS_STR = Arrays.asList("u", "d", "r", "l");
    private static final List<Node> DIRECTIONS2 = Arrays.asList(new Node(1, 1), new Node(1, -1), new Node(-1, -1),
            new Node(-1, 1));
    private static final List<Node> DIFF_NODE_THROW = Arrays.asList(new Node(0, 6), new Node(0, -6), new Node(6, 0),
            new Node(-6, 0));

    public static void main(String[] args) throws IOException {
        Hero hero = new Hero(GAME_ID, PLAYER_NAME, PLAYER_KEY);
        Emitter.Listener onMapUpdate = new Emitter.Listener() {
            GameMap gameMap;
            Player me;
            List<List<Integer>> g, trace;
            List<Node> restrictedNodes, restrictedNodesWithoutPlayers;
            List<Player> otherPlayers;
            int time = -1, previousDarkSide = 0;
            final EnemyMap enemyMap = new EnemyMap();
            TrackPlayer trackPlayer = new TrackPlayer();
            Inventory inventory;
            Action action;
            boolean haveGun;
            boolean haveMelee;
            List<HealingItem> healingItems;
            PointFactory pointFactory;

            void init() {
                time += 1;
                action.setHero(hero);
                haveGun = inventory.getGun() != null;
                haveMelee = inventory.getMelee().getId() != "Null";
                healingItems = inventory.getListHealingItem();
                pointFactory.setHero(hero);
                if (time == 0) {
                    trackPlayer.init(gameMap.getOtherPlayerInfo());
                }
                inventory = hero.getInventory();
                int currentDarkSide = gameMap.getDarkAreaSize();
                if (currentDarkSide != previousDarkSide) {
                    gameMap.setDarkAreaSize(currentDarkSide + 1);
                }
                previousDarkSide = currentDarkSide;
                trackPlayer.update(gameMap);
                me = gameMap.getCurrentPlayer();
                restrictedNodesWithoutPlayers = new ArrayList<>();
                restrictedNodes = new ArrayList<>();
                otherPlayers = new ArrayList<>();
                for (Player p : gameMap.getOtherPlayerInfo()) {
                    if (p.getIsAlive()) {
                        otherPlayers.add(p);
                    }
                }
                enemyMap.calcEnemy(gameMap, time);
                for (int i = 0; i < gameMap.getMapSize(); ++i) {
                    for (int j = 0; j < gameMap.getMapSize(); ++j) {
                        if (enemyMap.isBlock(time + 1, new Node(i, j), gameMap)) {
                            restrictedNodesWithoutPlayers.add(new Node(i, j));
                        }
                    }
                }
                List<Obstacle> listConstruct = gameMap.getListTraps();
                listConstruct.addAll(gameMap.getListIndestructibleObstacles());
                listConstruct.addAll(gameMap.getListChests());
                for (Node p : listConstruct) {
                    restrictedNodes.add(new Node(p.getX(), p.getY()));
                }

                restrictedNodesWithoutPlayers.addAll(restrictedNodes);
                for (Player p : otherPlayers) {
                    restrictedNodes.add(p);
                    int indexPlayer = trackPlayer.getIndexByName(p.getPlayerName());
                    if (trackPlayer.playerMelees.get(indexPlayer) == null
                            && trackPlayer.playerGuns.get(indexPlayer) == null) {
                        continue;
                    }
                    for (int i = 0; i < 4; ++i) {
                        Node nearPlayer = new Node(p.getX(), p.getY());
                        // gun.range()-1
                        for (int j = 0; j < 3; ++j) {
                            nearPlayer = Utils.add(nearPlayer, DIRECTIONS.get(i));
                            restrictedNodes.add(nearPlayer);
                            if (trackPlayer.playerGuns.get(indexPlayer) == null)
                                break;
                        }
                    }
                }

            }

            void bfs() {
                int mapSize = gameMap.getMapSize();

                g = Utils.initializeList(mapSize, 99999999);
                List<List<Boolean>> isRestrictedNodes = Utils.initializeList(mapSize, false);
                trace = Utils.initializeList(mapSize, -1);
                for (Node point : restrictedNodes) {
                    if (Utils.isValid(point, gameMap)) {
                        isRestrictedNodes.get(point.x).set(point.y, true);
                    }
                }
                Queue<Node> queue = new LinkedList<>();
                queue.add(me);
                g.get(me.getX()).set(me.getY(), 0);
                while (!queue.isEmpty()) {
                    Node u = queue.poll();
                    for (int dir = 0; dir < 4; ++dir) {
                        Node v = Utils.add(u, DIRECTIONS.get(dir));
                        if (!Utils.isValid(v, gameMap))
                            continue;
                        int cost = g.get(u.x).get(u.y) + 1;
                        if (Utils.isInsideSafeArea(me, gameMap)) {
                            if (enemyMap.isBlock(time + cost, v, gameMap)
                                    || !Utils.isInsideSafeArea(v, gameMap))
                                continue;
                        }
                        if (isRestrictedNodes.get(v.x).get(v.y)) {
                            continue;
                        }
                        if (g.get(v.x).get(v.y) > cost) {
                            g.get(v.x).set(v.y, cost);
                            trace.get(v.x).set(v.y, dir);
                            queue.add(v);
                        }
                    }
                }
            }

            String getPath(Node target) {
                if (Utils.equal(target, me)) {
                    return "";
                }
                while (true) {
                    int dir = trace.get(target.x).get(target.y);
                    String stringDir = DIRECTIONS_STR.get(dir);
                    target = Utils.add(target, DIRECTIONS_REVERSE.get(dir));
                    if (Utils.equal(target, me)) {
                        return stringDir;
                    }
                }
            }

            int distance(Node p) {
                if (p == null || !Utils.isValid(p, gameMap)) {
                    return 222222222;
                }
                return g.get(p.x).get(p.y);
            }

            boolean trapInMid(Node x, Node y, List<Obstacle> listTraps, List<Obstacle> listChest) {
                for (Obstacle mid : listTraps) {
                    if (Utils.distance(x, mid, gameMap) + Utils.distance(mid, y, gameMap) <= Utils.distance(x, y, gameMap)) {
                        return true;
                    }
                }
                for (Obstacle mid : listChest) {
                    if (Utils.distance(x, mid, gameMap) + Utils.distance(mid, y, gameMap) <= Utils.distance(x, y, gameMap)) {
                        return true;
                    }
                }
                return false;
            }

            <T extends Node> T nearestNode(List<T> nodes) {
                if (nodes.isEmpty()) {
                    return null;
                }
                T nearestNode = nodes.getFirst();
                for (T node : nodes) {
                    if (distance(node) < distance(nearestNode)) {
                        nearestNode = node;
                    }
                }
                return nearestNode;
            }

            void mAttack(Node target) {
                if (me.getX() + 1 == target.getX()) {
                    action.attack("r");
                }
                if (me.getX() - 1 == target.getX()) {
                    action.attack("l");
                }
                if (me.getY() + 1 == target.getY()) {
                    action.attack("u");
                }
                if (me.getY() - 1 == target.getY()) {
                    action.attack("d");
                }
            }

            void getItem(Node target) {
                if (Utils.equal(me, target)) {
                    action.pickupItem();
                } else {
                    action.move(getPath(target));
                }
            }

            void getChest(Node nextToChest) {
                if (Utils.equal(nextToChest, me)) {
                    for (Node p : gameMap.getListChests()) {
                        if (Utils.distance(p, me, gameMap) == 1) {
                            mAttack(p);
                            return;
                        }
                    }
                } else {
                    action.move(getPath(nextToChest));
                }
            }


            void getWeapon(Weapon weapon, int type) {
                if (Utils.equal(weapon, me)) {
                    if (type == 4) {
                        if (haveMelee) {
                            System.out.println("bo melee");
                            action.revokeItem(inventory.getMelee().getId());
                            return;
                        }
                    }
                    if (type == 5) {
                        if (haveGun) {
                            System.out.println("bo gun");
                            action.revokeItem(inventory.getGun().getId());
                            return;
                        }
                    }
                }
                getItem(weapon);
            }

            void getArmor(Armor armor) {
                if (Utils.equal(armor, me)) {

                }
                getItem(armor);
            }

            boolean contains(List<Node> list, Node node) {
                for (Node p : list) {
                    if (Utils.equal(p, node))
                        return true;
                }
                return false;
            }

            void calculateOptimizedMove() {
                List<Node> nextToChest = new ArrayList<>();
                for (Obstacle p : gameMap.getListChests()) {
                    if (!Utils.isInsideSafeArea(p, gameMap))
                        continue;
                    for (int i = 0; i < 4; ++i) {
                        nextToChest.add(Utils.add(p, DIRECTIONS.get(i)));
                    }
                }
                Node nearestNextToChest = nearestNode(nextToChest);
                Player nearestPlayer = null;
                Node nearestNextToPlayer = null;
                for (Player p : otherPlayers) {
                    if (!Utils.isInsideSafeArea(p, gameMap))
                        continue;
                    for (int i = 0; i < 4; ++i) {
                        Node addNode = Utils.add(p, DIRECTIONS2.get(i));
                        if (distance(addNode) < distance(nearestNextToPlayer)) {
                            nearestNextToPlayer = addNode;
                            nearestPlayer = p;
                        }
                    }
                }
                HealingItem nearestHealth = nearestNode(gameMap.getListHealingItems());
                Armor nearestArmor = nearestNode(gameMap.getListArmors());
                Weapon nearestMelee = nearestNode(gameMap.getAllMelee());
                Weapon nearestGun = nearestNode(gameMap.getAllGun());
                Weapon nearestThrow = nearestNode(gameMap.getAllThrowable());
                List<Double> pointItems = new ArrayList<>();
                pointItems.add(pointFactory.getPointChest(nearestNextToChest));
                pointItems.add(pointFactory.getPointPlayer(nearestPlayer, nearestNextToPlayer));
                pointItems.add(pointFactory.getPointHealth(nearestHealth));
                pointItems.add(pointFactory.getPointArmor(nearestArmor));
                pointItems.add(pointFactory.getPointWeapon(nearestMelee));
                pointItems.add(pointFactory.getPointWeapon(nearestGun));
                pointItems.add(pointFactory.getPointWeapon(nearestThrow));
                List<Node> target = new ArrayList<>();
                target.add(nearestNextToChest);
                target.add(nearestNextToPlayer);
                target.add(nearestHealth);
                target.add(nearestArmor);
                target.add(nearestMelee);
                target.add(nearestGun);
                target.add(nearestThrow);
                System.out.println("chest " + pointItems.get(0));
                System.out.println("player " + pointItems.get(1));
                System.out.println("health " + pointItems.get(2));
                System.out.println("armor " + pointItems.get(3));
                System.out.println("melee " + pointItems.get(4));
                System.out.println("gun " + pointItems.get(5));
                System.out.println("throw " + pointItems.get(6));
                Double maxPoint = Collections.max(pointItems);
                for (int i = 0; i < 7; ++i) {
                    if (Objects.equals(pointItems.get(i), maxPoint)) {
                        System.out.println("Move: " + i + " " + maxPoint);
                        System.out.println(
                                "Target2: " + target.get(i).getX() + " " + target.get(i).getY());
                        if (i == 0) {
                            getChest(target.get(i));
                        }
                        if (i == 1) {
                            int myHp = me.getHp() * (100 + me.getDamageReduction()) / 100;
                            System.out.println(
                                    "Step to kill: " + trackPlayer.getStepToKill(nearestPlayer.getPlayerName(), myHp));
                            action.move(getPath(target.get(i)));
                        }
                        if (i == 2) {
                            getItem(target.get(i));
                        }
                        if (i == 3) {
                            getArmor(nearestArmor);
                        }
                        if (i == 4) {
                            getWeapon(nearestMelee, i);
                        }
                        if (i == 5) {
                            getWeapon(nearestGun, i);
                        }
                        if (i == 6) {
                            getWeapon(nearestThrow, i);
                        }
                        return;
                    }
                }
            }

            boolean tryHealth() {
                if (healingItems.isEmpty()) {
                    return false;
                }
                int timeToReach = Integer.MAX_VALUE;
                int maxDame = 0;
                if (!otherPlayers.isEmpty()) {
                    Player nearestPlayerReal = otherPlayers.getFirst();
                    for (Player p : otherPlayers) {
                        if (Utils.distance(p, me, gameMap) < Utils.distance(nearestPlayerReal, me, gameMap)) {
                            nearestPlayerReal = p;
                        }
                    }
                    int diffX = Math.abs(nearestPlayerReal.getX() - me.getX());
                    int diffY = Math.abs(nearestPlayerReal.getY() - me.getY());
                    int indexPlayer = trackPlayer.getIndexByName(nearestPlayerReal.getPlayerName());
                    Weapon playerMelee = trackPlayer.playerMelees.get(indexPlayer);
                    Weapon playerGun = trackPlayer.playerGuns.get(indexPlayer);
                    if (playerMelee != null) {
                        timeToReach = diffX + diffY - 1;
                    }
                    if (playerGun != null) {
                        timeToReach = Math.min(diffX, diffY) + Math.max(0, Math.max(diffX, diffY) - 3);
                    }
                    if (timeToReach <= 4) {
                        maxDame = Utils.getDame(playerGun) + Utils.getDame(playerMelee);
                    }
                }
                int maxTimeUsage = timeToReach;
                if (haveGun && haveMelee) {
                    maxTimeUsage = Math.max(maxTimeUsage, Math.min(gunCooldown, meleeCooldown));
                }
                if (haveGun && !haveMelee) {
                    maxTimeUsage = Math.max(maxTimeUsage, gunCooldown);
                }
                if (!haveGun && haveMelee) {
                    maxTimeUsage = Math.max(maxTimeUsage, meleeCooldown);
                }
                if (timeToReach > 1) {
                    int maxTimeSafe = 0;
                    for (int i = 1; i <= 4; ++i) {
                        if (enemyMap.isBlock(time + i, me, gameMap))
                            break;
                        maxTimeSafe = i;
                    }
                    maxTimeUsage = Math.min(maxTimeSafe, timeToReach);
                }
                healingItems.sort((a, b) -> b.getHealingHP() - a.getHealingHP());
                for (HealingItem item : healingItems) {
                    if (me.getHp() + item.getHealingHP() <= 100 && maxTimeUsage >= item.getUsageTime()) {
                        action.useItem(item.getId());
                        stepHealing = item.getUsageTime();
                        return true;
                    }
                }
                if (me.getHp() <= maxDame) {
                    HealingItem item = healingItems.getLast();
                    if (maxTimeUsage >= item.getUsageTime()) {
                        action.useItem(healingItems.getLast().getId());
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void call(Object... args) {
                gameMap = hero.getGameMap();
                gameMap.updateOnUpdateMap(args[0]);
                init();
                if (stepHealing > 0) {
                    return;
                }
                bfs();
                System.out.println("Vi tri hien tai " + me.getX() + " " + me.getY());
                System.out.println("Co sung " + haveGun);
                System.out.println("Co dao " + haveMelee);
                System.out.println("Co nem " + haveThrow);
                System.out.println("gunCooldown " + gunCooldown);
                System.out.println("meleeCooldown " + meleeCooldown);
                System.out.println("bullet " + me.getBulletNum());
                System.out.println("size health " + listHealing.size());
                System.out.println("time " + time);
                if (!Utils.isInsideSafeArea(me, gameMap)) {
                    Node nearest = new Node(-1, -1);
                    for (int i = 0; i < gameMap.getMapSize(); ++i) {
                        for (int j = 0; j < gameMap.getMapSize(); ++j) {
                            Node addNode = new Node(i, j);
                            if (distance(addNode) < distance(nearest)
                                    && Utils.isInsideSafeArea(addNode, gameMap)) {
                                nearest = addNode;
                            }
                        }
                    }
                    action.move(getPath(nearest));
                    return;
                }
                if (haveMelee && meleeCooldown <= 0) {
                    for (Node p : otherPlayers) {
                        if (Utils.distance(me, p, gameMap) == 1) {
                            mAttack(p);
                            return;
                        }
                    }
                }
                if (haveGun && gunCooldown <= 0) {
                    for (Node p : otherPlayers) {
                        if (Math.abs(p.x - me.x) == 0 && Math.abs(p.y - me.y) <= gun.getRange()) {
                            if (trapInMid(me, p, gameMap.getListTraps(), gameMap.getListChests())) continue;
                            if (p.y < me.getY()) {
                                action.shoot("d");
                            } else {
                                action.shoot("u");
                            }
                            return;
                        }
                        if (Math.abs(p.y - me.y) == 0 && Math.abs(p.x - me.x) <= gun.getRange()) {
                            if (trapInMid(me, p, gameMap.getListTraps(), gameMap.getListChests())) continue;

                            if (p.x < me.getX()) {
                                action.shoot("l");
                            } else {
                                action.shoot("r");
                            }
                            return;
                        }
                    }
                }
                if (tryHealth()) {
                    return;
                }
                if (inventory.getThrowable() != null) {
                    List<Node> targetThrow = new ArrayList<>();
                    for (int i = 0; i < 4; ++i) {
                        targetThrow.add(Utils.add(DIFF_NODE_THROW.get(i), me));
                    }
                    for (Node p : otherPlayers) {
                        for (int i = 0; i < 4; ++i) {
                            if (Utils.distance(targetThrow.get(i), p, gameMap) <= 1) {
                                action.throwAttack(DIRECTIONS_STR.get(i));
                                return;
                            }
                        }
                    }
                }
                if ((haveGun && gunCooldown <= 1)
                        || (haveMelee && meleeCooldown <= 1)) {
                    for (Node p : otherPlayers) {
                        if (Math.abs(p.x - me.x) == 1 && Math.abs(p.y - me.y) == 1) {
                            if (me.y + 1 == p.y
                                    && !contains(restrictedNodesWithoutPlayers, new Node(me.x, me.y + 1))) {
                                action.move("u");
                                return;
                            }
                            if (me.y - 1 == p.y
                                    && !contains(restrictedNodesWithoutPlayers, new Node(me.x, me.y - 1))) {
                                action.move("d");
                                return;
                            }
                            action.move(PathUtils.getShortestPath(gameMap, restrictedNodesWithoutPlayers, me, p, false));
                            return;
                        }
                    }
                }
                calculateOptimizedMove();
            }
        };

        hero.setOnMapUpdate(onMapUpdate);
        hero.start(SERVER_URL);
    }
}
