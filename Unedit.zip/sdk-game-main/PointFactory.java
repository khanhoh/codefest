import jsclub.codefest2024.sdk.Hero;
import jsclub.codefest2024.sdk.base.Node;
import jsclub.codefest2024.sdk.model.ElementType;
import jsclub.codefest2024.sdk.model.equipments.Armor;
import jsclub.codefest2024.sdk.model.equipments.HealingItem;
import jsclub.codefest2024.sdk.model.players.Player;
import jsclub.codefest2024.sdk.model.weapon.Weapon;

import java.util.List;

public class PointFactory {
    Hero hero;
    List<HealingItem> healingItems;

    public void setHero(Hero hero) {
        this.hero = hero;
    }

    double getPointArmor(Armor armor) {
        if (armor == null)
            return 0;
        List<Armor> listArmor = hero.getInventory().getListArmor();
        int gainArmor = armor.getDamageReduce();
        for (Armor p : listArmor) {
            if (p.getType() == armor.getType()) {
                gainArmor = (armor.getDamageReduce() - p.getDamageReduce());
            }
        }
        return gainArmor * 800 / (Utils.distance(armor, hero) + 1);
    }

    double getPointHealth(int health) {
        if (healingItems.size() == 4)
            return 0;
        double urgencyFactor = 2 + (100.0 - me.getHp()) / 15;
        return (int) (health * 100 * urgencyFactor);
    }

    double getPointHealth(HealingItem health) {
        if (health == null)
            return 0;
        return getPointHealth(health.getHealingHP()) / (Utils.distance(health, hero) + health.getUsageTime() + 1);
    }

    double getPointPlayer(Player player, Node nextToPlayer) {
        if (player == null)
            return 0;
        int myHp = me.getHp() * (100 + me.getDamageReduction()) / 100;
        int playerHp = player.getHp() * (100 + player.getDamageReduction()) / 100;
        int stepToKillMe = trackPlayer.getStepToKill(player.getPlayerName(), myHp);
        int stepToKillPlayer = Utils.stepToKill(gun, melee, playerHp);
        double factor = Math.min(stepToKillMe * 1.0 / stepToKillPlayer, 1);
        factor = factor * factor;
        return (int) (100 * (player.getHp() + 35) * factor / (Utils.distance(nextToPlayer, hero) + 8));
    }

    double getPointWeapon(Weapon weapon) {
        if (weapon == null)
            return 0;
        int pointWeapon = 0;
        if (weapon.getType() == ElementType.THROWABLE) {
            if (!haveThrow) {
                pointWeapon = weapon.getDamage();
            }
        }
        if (weapon.getType() == ElementType.MELEE) {
            pointWeapon = (weapon.getDamage() - Utils.getDame(melee)) * 4;
        }
        if (weapon.getType() == ElementType.GUN) {
            pointWeapon = (weapon.getDamage() - Utils.getDame(gun)) * 4;
        }
        return pointWeapon * 100 / (distance(weapon) + 1);
    }

    double getPointChest(Node chest) {
        if (chest == null)
            return 0;
        int pointChest = 0;
        if (me.getDamageReduction() < 20) {
            pointChest += 20 * 800 * (1 - Math.pow(1 - 0.02, 4));
        }
        if (me.getDamageReduction() == 20 || me.getDamageReduction() == 0) {
            pointChest += 5 * 800 * (1 - Math.pow(1 - 0.03, 4)) + 10 * 800 * (1 - Math.pow(1 - 0.05, 4));
        }
        pointChest += getPointHealth(15);
        if (Utils.getDame(melee) <= 45) {
            pointChest += (55 - Utils.getDame(melee)) * 400 * (1 - Math.pow(1 - 0.05, 4));
        }
        if (Utils.getDame(melee) == 0) {
            pointChest += 45 * 400 * (1 - Math.pow(1 - 0.16, 4));
        }
        if (!haveThrow) {
            pointChest += 25 * 100 * (1 - Math.pow(1 - 0.40, 4));
        }
        return pointChest / (distance(chest) + 4);
    }
}
